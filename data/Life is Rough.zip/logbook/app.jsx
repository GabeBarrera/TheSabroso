/* ===== Field Logbook — App ===== */
const { useState, useEffect, useRef, useLayoutEffect, useCallback } = React;

function reducedMotion() {
  return window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function App() {
  const [entries, setEntries] = useState(() => LB.loadEntries());
  const [pages, setPages] = useState([]);
  const [idx, setIdx] = useState(() => LB.loadPage());
  const [flip, setFlip] = useState(null);
  const [run, setRun] = useState(false);
  const [editorOpen, setEditorOpen] = useState(false);
  const [scale, setScale] = useState(1);

  const flippingRef = useRef(false);
  const flipRef = useRef(null);
  const pendingNav = useRef(null);
  const areaRef = useRef(null);

  useEffect(() => { flipRef.current = flip; }, [flip]);

  /* paginate (after fonts load) whenever entries change */
  useEffect(() => {
    let alive = true;
    const go = () => {
      if (!alive) return;
      const p = LB.paginate(entries);
      setPages(p);
      if (pendingNav.current) {
        const t = p.findIndex(pg => pg.chapterId === pendingNav.current && pg.isChapterStart);
        pendingNav.current = null;
        if (t >= 0) setIdx(t);
      } else {
        setIdx(i => Math.max(0, Math.min(i, p.length - 1)));
      }
    };
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(go);
    else go();
    return () => { alive = false; };
  }, [entries]);

  useEffect(() => { LB.saveEntries(entries); }, [entries]);
  useEffect(() => { LB.savePage(idx); }, [idx]);

  /* fit-to-area scaling */
  useLayoutEffect(() => {
    const el = areaRef.current;
    if (!el) return;
    function fit() {
      const w = el.clientWidth - 120;
      const h = el.clientHeight - 120;
      if (w <= 0 || h <= 0) return;
      setScale(Math.max(0.25, Math.min(w / LB.PAGE_W, h / LB.PAGE_H, 1.5)));
    }
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(el);
    window.addEventListener("resize", fit);
    return () => { ro.disconnect(); window.removeEventListener("resize", fit); };
  }, []);

  /* ---- turning ---- */
  const goTo = useCallback((target) => {
    if (flippingRef.current) return;
    if (target < 0 || target >= pages.length || target === idx) return;
    if (reducedMotion()) { setIdx(target); return; }
    flippingRef.current = true;
    const dir = target > idx ? "fwd" : "bwd";
    const curPage = pages[idx], dstPage = pages[target];
    if (dir === "fwd") {
      setFlip({ dir, target, beneath: dstPage, frontPage: curPage, backPage: dstPage, start: "0deg", end: "-180deg" });
    } else {
      setFlip({ dir, target, beneath: curPage, frontPage: dstPage, backPage: curPage, start: "-180deg", end: "0deg" });
    }
  }, [pages, idx]);

  const onTurn = useCallback((delta) => { goTo(idx + delta); }, [goTo, idx]);

  const finalize = useCallback(() => {
    if (!flippingRef.current) return;
    const f = flipRef.current;
    flippingRef.current = false;
    setFlip(null);
    setRun(false);
    if (f) setIdx(f.target);
  }, []);

  /* trigger transition after flipper mounts, with a timeout fallback
     (covers reduced-motion / dropped transitionend so a turn never sticks) */
  useEffect(() => {
    if (!flip) return;
    setRun(false);
    const t1 = setTimeout(() => setRun(true), 32);
    const t2 = setTimeout(finalize, 1120);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [flip, finalize]);

  const onFlipEnd = useCallback((e) => {
    if (e && e.propertyName && e.propertyName !== "transform") return;
    finalize();
  }, [finalize]);

  /* keyboard */
  useEffect(() => {
    function onKey(e) {
      if (editorOpen) return;
      const tag = (document.activeElement && document.activeElement.tagName) || "";
      if (tag === "INPUT" || tag === "TEXTAREA" || (document.activeElement && document.activeElement.isContentEditable)) return;
      if (e.key === "ArrowRight" || e.key === "PageDown") { e.preventDefault(); onTurn(1); }
      else if (e.key === "ArrowLeft" || e.key === "PageUp") { e.preventDefault(); onTurn(-1); }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onTurn, editorOpen]);

  /* TOC jump */
  const jumpToChapter = useCallback((chapterId) => {
    const t = pages.findIndex(p => p.chapterId === chapterId && p.isChapterStart);
    if (t >= 0) goTo(t);
  }, [pages, goTo]);

  /* save new entry */
  const onSaveEntry = useCallback((entry) => {
    pendingNav.current = entry.id;
    setEntries(prev => [...prev, entry]);
    setEditorOpen(false);
  }, []);

  /* chapters list with page ranges */
  const chapters = entries.map(e => {
    const ps = pages.filter(p => p.chapterId === e.id);
    return {
      id: e.id, title: e.title,
      start: ps.length ? ps[0].number : 0,
      end: ps.length ? ps[ps.length - 1].number : 0
    };
  });
  const activeId = pages[idx] ? pages[idx].chapterId : null;

  return React.createElement("div", { className: "app" },
    React.createElement(Sidebar, {
      chapters, activeId,
      onJump: jumpToChapter,
      onNew: () => setEditorOpen(true)
    }),
    React.createElement("div", { ref: areaRef, style: { flex: "1 1 auto", position: "relative", display: "flex" } },
      pages.length > 0
        ? React.createElement(Book, { pages, idx, flip, run, onTurn, onFlipEnd, scale })
        : React.createElement("div", { className: "book-area" })
    ),
    editorOpen && React.createElement(Editor, {
      onSave: onSaveEntry,
      onClose: () => setEditorOpen(false)
    })
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(App));
