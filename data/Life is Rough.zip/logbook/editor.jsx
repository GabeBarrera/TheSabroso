/* ===== Field Logbook — New Entry editor ===== */
const { useState: useStateE, useRef: useRefE, useEffect: useEffectE } = React;

function Editor({ onSave, onClose }) {
  const areaRef = useRefE(null);
  const [title, setTitle] = useStateE("");
  const [date, setDate] = useStateE(LB.todayStamp());

  useEffectE(() => {
    if (areaRef.current) {
      areaRef.current.innerHTML = "<p><br></p>";
      areaRef.current.focus();
    }
  }, []);

  function cmd(c, v) {
    areaRef.current && areaRef.current.focus();
    document.execCommand(c, false, v);
  }
  function block(tag) {
    areaRef.current && areaRef.current.focus();
    document.execCommand("formatBlock", false, tag);
  }
  function insertDate() {
    areaRef.current && areaRef.current.focus();
    document.execCommand("insertText", false, LB.todayStamp() + " \u2014 ");
  }
  function insertPlate() {
    areaRef.current && areaRef.current.focus();
    document.execCommand("insertHTML", false, LB.PLATE("field sketch", "Pl. \u2014 ") + "<p><br></p>");
  }

  function save() {
    const html = (areaRef.current ? areaRef.current.innerHTML : "").trim();
    onSave({
      id: "e-" + Date.now().toString(36),
      title: title.trim() || "Untitled Entry",
      date: date.trim(),
      html: html === "<p><br></p>" ? "<p></p>" : html
    });
  }

  const T = (props, ...kids) => React.createElement("button",
    Object.assign({ className: "tb-btn", onMouseDown: e => e.preventDefault() }, props), ...kids);
  const Sep = () => React.createElement("span", { className: "tb-sep" });

  return React.createElement("div", {
    className: "modal-scrim",
    onMouseDown: e => { if (e.target.classList.contains("modal-scrim")) onClose(); }
  },
    React.createElement("div", { className: "editor" },
      React.createElement("div", { className: "paper-grain" }),
      React.createElement("div", { className: "ed-head" },
        React.createElement("h2", null, "New Field Entry"),
        React.createElement("div", { className: "ed-mark" }, "Logbook \u00b7 recto")
      ),
      React.createElement("div", { className: "ed-fields" },
        React.createElement("label", { className: "f-title" }, "Title",
          React.createElement("input", {
            value: title, onChange: e => setTitle(e.target.value),
            placeholder: "e.g. Owls at Dusk", autoFocus: false
          })
        ),
        React.createElement("label", { className: "f-date" }, "Date stamp",
          React.createElement("input", { value: date, onChange: e => setDate(e.target.value) })
        )
      ),
      React.createElement("div", { className: "toolbar" },
        T({ className: "tb-btn b", onClick: () => cmd("bold"), title: "Bold" }, "B"),
        T({ className: "tb-btn i", onClick: () => cmd("italic"), title: "Italic" }, "I"),
        T({ className: "tb-btn u", onClick: () => cmd("underline"), title: "Underline" }, "U"),
        Sep(),
        T({ onClick: () => block("<h2>"), title: "Heading" }, "H"),
        T({ onClick: () => block("<p>"), title: "Body text", className: "tb-btn tb-mono" }, "\u00b6"),
        T({ onClick: () => block("<blockquote>"), title: "Quote" }, "\u201C"),
        Sep(),
        T({ onClick: () => cmd("insertUnorderedList"), title: "Bulleted list", className: "tb-btn tb-mono" }, "\u2022"),
        T({ onClick: () => cmd("insertOrderedList"), title: "Numbered list", className: "tb-btn tb-mono" }, "1."),
        Sep(),
        T({ onClick: () => cmd("justifyLeft"), title: "Align left", className: "tb-btn tb-mono" }, "\u2261"),
        T({ onClick: () => cmd("justifyCenter"), title: "Align center", className: "tb-btn tb-mono" }, "\u2632"),
        T({ onClick: () => cmd("justifyRight"), title: "Align right", className: "tb-btn tb-mono" }, "\u2630"),
        Sep(),
        T({ onClick: insertDate, title: "Insert date stamp", className: "tb-btn tb-mono" }, "\u2316"),
        T({ onClick: () => cmd("insertHorizontalRule"), title: "Divider", className: "tb-btn tb-mono" }, "\u2014"),
        T({ onClick: insertPlate, title: "Insert image placeholder", className: "tb-btn tb-mono" }, "\u25AD")
      ),
      React.createElement("div", {
        className: "ed-area page-content", ref: areaRef, contentEditable: true, suppressContentEditableWarning: true
      }),
      React.createElement("div", { className: "ed-foot" },
        React.createElement("button", { className: "btn btn-ghost", onClick: onClose }, "Cancel"),
        React.createElement("button", { className: "btn btn-save", onClick: save }, "Save Entry")
      )
    )
  );
}
window.Editor = Editor;
