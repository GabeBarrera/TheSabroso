/* ===== Field Logbook — data, storage, pagination ===== */
window.LB = (function () {
  const PAGE_W = 860, PAGE_H = 1140;
  const PAD_X = 80, PAD_TOP = 96, PAD_BOT = 96;
  const CONTENT_W = PAGE_W - PAD_X * 2;          // 700
  const CONTENT_H = PAGE_H - PAD_TOP - PAD_BOT;  // 948

  const PLATE = (label, cap) =>
    `<figure class="plate"><div class="plate-box"><span>${label}</span></div>` +
    (cap ? `<figcaption>${cap}</figcaption>` : ``) + `</figure>`;

  const SEED = [
    {
      id: "e-marsh",
      title: "Marsh at First Light",
      date: "14 April",
      html:
        `<p>Reached the reed beds before the sun cleared the eastern stand of alders. The fog sat low and unbroken across the water, so that the marsh seemed less a place than a held breath. I set the canvas stool at the old blind and did not move for the better part of an hour.</p>` +
        `<p>Sound arrives before sight here. First the small chatter of wrens working the cattails, then the deeper note of frogs winding down from their night chorus, and at last the wet clap of something larger shifting its weight in the shallows.</p>` +
        PLATE("marsh panorama — dawn", "Pl. I — the north blind, looking east") +
        `<blockquote>Stillness is its own kind of motion; the patient watcher is repaid in full.</blockquote>` +
        `<p>By the time the fog lifted, the temperature had climbed perhaps four degrees and the surface of the water had gone from pewter to a pale, beaten gold. I counted nine species before packing the glass away.</p>`
    },
    {
      id: "e-heron",
      title: "The Heron's Patience",
      date: "16 April",
      html:
        `<p>A great blue stood at the far margin for the whole of my visit, neither feeding nor resting, simply present. There is a lesson in a bird that can outwait the tide.</p>` +
        `<p>Notes taken at intervals of roughly ten minutes:</p>` +
        `<ul><li>06:40 — wading, slow, one step per minute</li><li>06:55 — frozen, neck drawn into an S, eye fixed downward</li><li>07:20 — single strike; a small silver fish, swallowed whole</li><li>07:45 — preening on the gravel bar, unhurried</li></ul>` +
        `<p>It left without ceremony, a slow opening of wings that seemed too large for the quiet they made.</p>`
    },
    {
      id: "e-lichen",
      title: "Lichen Survey — North Ridge",
      date: "21 April",
      html:
        `<p>A long climb to the exposed shoulder of the ridge, where the wind keeps the trees low and the rock is given over almost entirely to lichen. What looks at a distance like bare grey stone is, up close, a teeming country of its own.</p>` +
        `<h2>Method</h2>` +
        `<p>I laid a half-metre quadrat at three stations along the contour, photographing each and recording cover by eye. The frame is crude but the hand is honest, and over many seasons even rough numbers begin to speak.</p>` +
        `<ol><li>Station A — windward face, full exposure</li><li>Station B — lee of the cairn, sheltered</li><li>Station C — the seep below the false summit</li></ol>` +
        PLATE("quadrat A — windward rock", "Pl. II — crustose mosaic, Station A") +
        `<h2>Observations</h2>` +
        `<p>The windward stone is dominated by tight crustose forms, pressed so close to the rock that a knife would not part them from it. Map lichen draws its thin black borders between territories of yellow-green, each patch a sovereign nation expanding by a hair's width a year.</p>` +
        `<p>In the shelter of the cairn the character changes entirely. Here the foliose kinds take hold, lifting their grey-green lobes a few millimetres into the air, and in the dampest seams a beard lichen hangs in pale threads from the underside of the rock.</p>` +
        `<blockquote>To measure the growth of a thing that moves a millimetre in a year is to be reminded how brief one's own attention is.</blockquote>` +
        `<p>The seep at Station C is the richest by far. Constant moisture has let the leafy and shrubby forms run riot, and a single hand's-breadth held perhaps a dozen distinct species, layered one upon another like a city built and rebuilt on its own ruins.</p>` +
        `<h2>Notes for next season</h2>` +
        `<ul><li>Return earlier — the windward crust is best photographed wet, just after the morning fog</li><li>Bring the loupe with the longer working distance</li><li>Mark Station C discreetly; the seep is fragile underfoot</li></ul>` +
        `<hr>` +
        `<p>Descended in failing light with cold hands and a full notebook, which is the proper proportion for a good day's work.</p>`
    },
    {
      id: "e-tracks",
      title: "Tracks in the Snowmelt",
      date: "29 April",
      html:
        `<p>The last of the high snow is going fast, and the bare ground at its edge holds a perfect ledger of the night's traffic. I walked the melt line slowly, reading.</p>` +
        PLATE("track cast — canid", "Pl. III — single print, mud at melt edge") +
        `<p>A fox had passed in the small hours, its prints set down in the neat single file that distinguishes it from the loose, four-square amble of a dog. Where the trail crossed a vole's runway it paused — two prints close together, then a pounce.</p>` +
        `<blockquote>The snow keeps no secrets; it only waits for someone willing to kneel and read them.</blockquote>` +
        `<p>Deer had come down to the seep as well, and a single set of broad, splayed prints I take to be a hare, already half-erased by the rising sun. By noon the whole record will have melted into ordinary mud.</p>`
    },
    {
      id: "e-kit",
      title: "Provisions & Field Kit",
      date: "2 May",
      html:
        `<p>A note to my future self, who will certainly have forgotten something. The kit that has earned its place, after a season of carrying too much:</p>` +
        `<h2>Always</h2>` +
        `<ul><li>This book, and two pencils — never a pen in the wet</li><li>Loupe, 10×, on a cord</li><li>The small brass glass; the heavy binoculars stay home now</li><li>Half-metre cord, knotted, for quadrats</li></ul>` +
        `<h2>Provisions</h2>` +
        `<ul><li>Hard cheese, oatcakes, an apple</li><li>Tea in the dented flask</li><li>More water than seems reasonable</li></ul>` +
        `<p>Everything else is luxury, and luxury is weight, and weight is the enemy of the long, slow, watchful day.</p>`
    }
  ];

  /* ---------- storage ---------- */
  const KEY = "fieldlog.entries.v1";
  const PKEY = "fieldlog.page.v1";
  function loadEntries() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) { const v = JSON.parse(raw); if (Array.isArray(v) && v.length) return v; }
    } catch (e) {}
    return SEED.map(e => ({ ...e }));
  }
  function saveEntries(entries) {
    try { localStorage.setItem(KEY, JSON.stringify(entries)); } catch (e) {}
  }
  function loadPage() {
    try { const n = parseInt(localStorage.getItem(PKEY), 10); if (!isNaN(n) && n >= 0) return n; } catch (e) {}
    return 0;
  }
  function savePage(n) { try { localStorage.setItem(PKEY, String(n)); } catch (e) {} }

  /* ---------- measurer ---------- */
  let _m = null;
  function measurer() {
    if (_m && document.body.contains(_m)) return _m;
    _m = document.createElement("div");
    _m.className = "page-content";
    _m.style.cssText =
      `position:absolute;left:-12000px;top:0;width:${CONTENT_W}px;height:auto;` +
      `overflow:visible;visibility:hidden;pointer-events:none;`;
    document.body.appendChild(_m);
    return _m;
  }

  /* ---------- pagination ---------- */
  function buildBlocks(entry) {
    const blocks = [
      `<header class="chap-head">` +
        `<div class="chap-stamp">${entry.date || ""}</div>` +
        `<h1 class="chap-title">${entry.title || "Untitled"}</h1>` +
        `<div class="chap-rule"></div></header>`
    ];
    const tmp = document.createElement("div");
    tmp.innerHTML = entry.html || "";
    Array.from(tmp.children).forEach(ch => blocks.push(ch.outerHTML));
    if (tmp.children.length === 0 && (entry.html || "").trim()) {
      blocks.push(`<p>${entry.html}</p>`);
    }
    return blocks;
  }

  function paginate(entries) {
    const m = measurer();
    m.innerHTML = "";
    const pages = [];
    let cur = null;

    function startPage(entry, isStart) {
      cur = { chapterId: entry.id, title: entry.title, isChapterStart: isStart, html: "" };
      pages.push(cur);
      m.innerHTML = "";
    }
    function commit() { if (cur) cur.html = m.innerHTML; }
    function canSplit(html) { return /^\s*<(p|blockquote)[\s>]/i.test(html); }

    function splitWords(html) {
      const tmp = document.createElement("div");
      tmp.innerHTML = html;
      const el = tmp.firstElementChild;
      const tag = el.tagName.toLowerCase();
      const cls = el.getAttribute("class");
      const open = `<${tag}${cls ? ` class="${cls}"` : ""}>`;
      const words = el.textContent.split(/(\s+)/);
      m.innerHTML = "";
      const test = document.createElement(tag);
      if (cls) test.className = cls;
      m.appendChild(test);
      let acc = "", i = 0;
      for (; i < words.length; i++) {
        test.textContent = acc + words[i];
        if (m.scrollHeight > CONTENT_H && acc.trim()) break;
        acc += words[i];
      }
      const rest = words.slice(i).join("");
      m.innerHTML = "";
      return [open + acc.trim() + `</${tag}>`, rest.trim() ? open + rest.trim() + `</${tag}>` : null];
    }

    function addBlock(html, entry) {
      if (!cur) startPage(entry, true);
      m.insertAdjacentHTML("beforeend", html);
      if (m.scrollHeight > CONTENT_H) {
        if (m.children.length === 1) {
          if (canSplit(html)) {
            const [fit, rest] = splitWords(html);
            m.innerHTML = "";
            m.insertAdjacentHTML("beforeend", fit);
            commit();
            if (rest) { startPage(entry, false); addBlock(rest, entry); }
            return;
          } else { commit(); return; } // oversize, non-split block: accept (clipped)
        } else {
          m.removeChild(m.lastChild);
          commit();
          startPage(entry, false);
          addBlock(html, entry);
          return;
        }
      } else { commit(); }
    }

    entries.forEach(entry => {
      startPage(entry, true);             // each chapter opens a fresh page
      buildBlocks(entry).forEach(b => addBlock(b, entry));
    });
    pages.forEach((p, i) => { p.number = i + 1; });
    m.innerHTML = "";
    return pages;
  }

  function todayStamp() {
    const d = new Date();
    const months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
    return `${d.getDate()} ${months[d.getMonth()]}`;
  }

  return {
    PAGE_W, PAGE_H, PAD_X, PAD_TOP, PAD_BOT, CONTENT_W, CONTENT_H,
    PLATE, loadEntries, saveEntries, loadPage, savePage,
    paginate, todayStamp
  };
})();
