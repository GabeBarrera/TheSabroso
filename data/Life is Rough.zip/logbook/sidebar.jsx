/* ===== Field Logbook — Sidebar (numbered TOC) ===== */
function Sidebar({ chapters, activeId, onJump, onNew }) {
  return React.createElement("aside", { className: "sidebar" },
    React.createElement("div", { className: "sb-head" },
      React.createElement("div", { className: "sb-mark" }, "Field Notes"),
      React.createElement("h1", { className: "sb-title" }, "The Logbook"),
      React.createElement("div", { className: "sb-sub" }, "naturalist's record")
    ),
    React.createElement("div", { className: "sb-toc-label" }, "Contents"),
    React.createElement("nav", { className: "toc" },
      chapters.map((c, i) =>
        React.createElement("button", {
          key: c.id,
          className: "toc-item" + (c.id === activeId ? " active" : ""),
          onClick: () => onJump(c.id)
        },
          React.createElement("span", { className: "toc-num" }, String(i + 1).padStart(2, "0")),
          React.createElement("span", null,
            React.createElement("span", { className: "toc-title" }, c.title),
            React.createElement("span", { className: "toc-pages" },
              c.start === c.end ? ("p. " + c.start) : ("pp. " + c.start + "\u2013" + c.end))
          )
        )
      )
    ),
    React.createElement("div", { className: "sb-foot" },
      React.createElement("button", { className: "new-btn", onClick: onNew },
        React.createElement("span", { className: "plus" }, "+"),
        "New Entry"
      )
    )
  );
}
window.Sidebar = Sidebar;
