/* ===== Field Logbook — Page + Book (3D curl) ===== */
const { useState: useStateB, useEffect: useEffectB, useRef: useRefB } = React;

function Page({ page }) {
  if (!page) return null;
  return (
    React.createElement("div", { className: "paper" },
      React.createElement("div", { className: "page-inner" },
        !page.isChapterStart &&
          React.createElement("div", { className: "runhead" },
            React.createElement("span", null, page.title),
            React.createElement("em", null, "cont.")
          ),
        React.createElement("div", {
          className: "page-content",
          dangerouslySetInnerHTML: { __html: page.html }
        }),
        React.createElement("div", { className: "page-foot" }, "\u2014 " + page.number + " \u2014")
      ),
      React.createElement("div", { className: "paper-grain" }),
      React.createElement("div", { className: "paper-vignette" })
    )
  );
}

function Book({ pages, idx, flip, run, onTurn, onFlipEnd, scale }) {
  const startRef = useRefB(null);

  // swipe via pointer
  function onPointerDown(e) {
    if (e.target.closest(".nav-btn")) return;
    startRef.current = { x: e.clientX, y: e.clientY, t: Date.now() };
  }
  function onPointerUp(e) {
    const s = startRef.current;
    startRef.current = null;
    if (!s) return;
    const dx = e.clientX - s.x, dy = e.clientY - s.y;
    if (Math.abs(dx) < 55 || Math.abs(dx) < Math.abs(dy)) return;
    onTurn(dx < 0 ? 1 : -1);
  }

  const beneath = flip ? flip.beneath : pages[idx];
  const total = pages.length;

  return React.createElement("div", {
    className: "book-area",
    onPointerDown, onPointerUp
  },
    React.createElement("button", {
      className: "nav-btn nav-prev", onClick: () => onTurn(-1),
      disabled: !!flip || idx <= 0, "aria-label": "Previous page"
    }, "\u2039"),

    React.createElement("div", { className: "book-scale", style: { transform: `scale(${scale})` } },
      React.createElement("div", { className: "book-viewport" },
        React.createElement(Page, { page: beneath }),
        flip && React.createElement("div", { className: "flipper", onTransitionEnd: onFlipEnd,
          style: { transform: `rotateY(${run ? flip.end : flip.start})` } },
          React.createElement("div", { className: "face front" },
            React.createElement(Page, { page: flip.frontPage })),
          React.createElement("div", { className: "face back" },
            React.createElement(Page, { page: flip.backPage }))
        ),
        flip && run && React.createElement("div", { className: "cast " + flip.dir })
      )
    ),

    React.createElement("button", {
      className: "nav-btn nav-next", onClick: () => onTurn(1),
      disabled: !!flip || idx >= total - 1, "aria-label": "Next page"
    }, "\u203A"),

    React.createElement("div", { className: "hint" }, "\u2190 \u2192  keys  \u00b7  swipe  \u00b7  click an entry"),
    React.createElement("div", { className: "page-indicator" }, (idx + 1) + " / " + total)
  );
}

window.Page = Page;
window.Book = Book;
